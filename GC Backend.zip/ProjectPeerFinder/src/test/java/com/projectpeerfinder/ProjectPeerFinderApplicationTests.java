package com.projectpeerfinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectPeerFinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
