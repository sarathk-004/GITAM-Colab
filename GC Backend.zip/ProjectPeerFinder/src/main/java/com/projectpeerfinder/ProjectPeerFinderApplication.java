package com.projectpeerfinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectPeerFinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectPeerFinderApplication.class, args);
	}

}
